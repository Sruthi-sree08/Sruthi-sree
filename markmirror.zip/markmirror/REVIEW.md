# Code review: mistakes found and corrections

**Verdict on the original:** the core grading maths was correct (the demo student
22CSE104 gives exactly SGPA 8.85, and no student has invalid internal/external marks).
The mistakes were in edge cases, accessibility and robustness. All are fixed in this zip.

## A. Real bugs (wrong output)

| # | Mistake in original | Why it is wrong | Correct version |
|---|---|---|---|
| 1 | Trend chart `y: { min: 4, max: 10 }` | 3 students have SGPA below 4 (lowest 3.3). Their latest point is drawn off the chart, so the sheet hides the real result. | `y: { min: 0, max: 10 }` |
| 2 | Past-semester SGPA `clamp(..., 5, 10)` | Forces earlier semesters up to 5 even when the current SGPA is lower, giving impossible histories and wrong CGPA for 5 students. | `clamp(..., 0, 10)` (0 affected students now) |
| 3 | Toppers list ranked everyone by SGPA | A student with an F is not a topper; it only avoided this by luck of the seed. | Filter `subjects.every(grade !== "F")` and show an empty-state message |
| 4 | Chart font set inside `initAnalytics()` | The marksheet trend chart (built before the analytics tab opens) used a different font from the rest. | Set `Chart.defaults` once at load |
| 5 | Empty or malformed hall ticket gave "No result found for ''" | Confusing message; no format check. | Separate messages for empty, bad format (`/^\d{2}[A-Z]{2,3}\d{3}$/`) and not found |
| 6 | If the Chart.js CDN fails, `new Chart` throws | The marksheet half-renders and analytics break. | `makeChart()` guard shows a clear fallback message |

## B. Accessibility and usability (typically marked)

| # | Mistake | Fix |
|---|---|---|
| 7 | Tabs were plain buttons with no ARIA | `role=tablist/tab/tabpanel`, `aria-selected`, `aria-controls`, arrow-key navigation |
| 8 | Leaderboard rows were clickable `<li>` (mouse only) | Each row is a real `<button>` with a descriptive `aria-label` |
| 9 | Charts had no text alternative | `role="img"` and `aria-label` on every canvas; trend label lists each SGPA |
| 10 | Table had no caption or `scope` | Added `<caption class="sr-only">` and `scope="col"` |
| 11 | Chart animations ignored `prefers-reduced-motion` (CSS rule only covers CSS) | `Chart.defaults.animation = false` when reduced motion is requested |
| 12 | After a lookup, focus stayed on the form | Focus moves to the marksheet heading |
| 13 | Inline `onclick="window.print()"` | `addEventListener` (cleaner, CSP-friendly) |
| 14 | Header said "Total" with no scale; credits had no denominator | "Total /100" and "Credits earned x / 20" |

## C. Hardening and polish

15. All dynamic text passes through `esc()` before `innerHTML` (prevents HTML injection if data ever comes from a real source).
16. Added meta description, favicon, `<noscript>` message, `autocapitalize`, `spellcheck=false`, `maxlength`.
17. Print stylesheet adds `break-inside: avoid` and disables table scrolling so the A4 sheet never clips.
18. CGPA is a simple mean of SGPAs. This is correct only for equal-credit semesters; documented in README.

## D. Verification performed
- Syntax check passes (`node --check`).
- Logic run headless over all 100 students: demo SGPA 8.85, CGPA 8.56; internal 0–40 and external 0–60 for every subject; no student has a backlog in the top 10.
- Every element ID used by the script exists in the HTML.
- Not tested in a real browser here (no network for Chart.js); open `index.html` and try 22CSE104, a bad ticket, the Analytics tab, and Print.
