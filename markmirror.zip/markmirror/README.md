# MarkMirror – ResultRadar

A front-end-only student result portal: hall-ticket lookup with a printable
grade sheet, plus batch analytics (pass rates, grade mix, CGPA spread, toppers).

## Run
Open `index.html` in a browser (internet needed once for Chart.js and Google Fonts).
Try hall ticket **22CSE104** (SGPA 8.85).

## Files
| File | Purpose |
|---|---|
| index.html | Page structure, accessible tabs |
| style.css  | Styling, responsive layout, A4 print stylesheet |
| app.js     | Grading rules, seeded data (100 students), marksheet, analytics |
| REVIEW.md  | Mistakes found in the original and the corrected versions |

## Grading rules
Grade from total/100: O ≥90, A+ ≥80, A ≥70, B+ ≥60, B ≥50, C ≥45, P ≥40, F <40.
Points: O10 A+9 A8 B+7 B6 C5 P4 F0.
SGPA = Σ(credits × points) ÷ Σ credits. CGPA = mean of semester SGPAs
(valid because every semester is assumed to carry equal credits).
Any F → "Backlog – re-appear".
