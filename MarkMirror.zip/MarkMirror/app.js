/* ========== STEP A: Grading rules & subjects ========== */
const GP = { O: 10, "A+": 9, A: 8, "B+": 7, B: 6, C: 5, P: 4, F: 0 };
const SUBJECTS = [
  { code: "MA201", name: "Mathematics",          credits: 4, mean: 72 },
  { code: "CS202", name: "DBMS",                 credits: 4, mean: 74 },
  { code: "CS203", name: "Operating Systems",    credits: 4, mean: 46 }, // low mean -> toughest paper
  { code: "CS204", name: "Computer Networks",    credits: 3, mean: 68 },
  { code: "CS205", name: "Software Engineering", credits: 3, mean: 76 },
  { code: "CS206", name: "AI Lab",               credits: 2, mean: 82 },
];
const gradeOf = t => t >= 90 ? "O" : t >= 80 ? "A+" : t >= 70 ? "A" : t >= 60 ? "B+" :
                     t >= 50 ? "B" : t >= 45 ? "C" : t >= 40 ? "P" : "F";
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const round1 = n => Math.round(n * 10) / 10;
const round2 = n => Math.round(n * 100) / 100;

/* Credit-weighted GPA: sum(credits * gradePoints) / sum(credits) */
function sgpaOf(subs) {
  const credits = subs.reduce((a, s) => a + s.credits, 0);
  return round2(subs.reduce((a, s) => a + s.credits * s.points, 0) / credits);
}
const classOf = st =>
  st.subjects.some(s => s.grade === "F") ? "Backlog – re-appear" :
  st.sgpa >= 8.5 ? "First Class with Distinction" :
  st.sgpa >= 7 ? "First Class" : st.sgpa >= 6 ? "Second Class" : "Pass Class";

/* ========== STEP B: Generate 100 realistic student records ========== */
function rng(a) { // seeded random so data is the same on every load
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
const rnd = rng(2024);
const pick = a => a[Math.floor(rnd() * a.length)];
const FIRST = ["Aarav","Ananya","Vihaan","Diya","Rohan","Meera","Karthik","Sneha","Arjun","Priya","Ishaan","Kavya","Rahul","Nisha","Sai","Lakshmi"];
const LAST = ["Reddy","Sharma","Kumar","Rao","Patel","Nair","Iyer","Gupta","Naidu","Verma"];
const BRANCHES = { CSE: ["Computer Science", 40], ECE: ["Electronics", 30], IT: ["Information Technology", 30] };

function build(hallTicket, name, branch, totals, history) {
  const subjects = SUBJECTS.map((s, i) => {
    const total = totals[i];
    const internal = Math.max(total - 60, Math.min(40, Math.round(total * 0.4 + (rnd() - 0.5) * 6)));
    const grade = gradeOf(total);
    return { ...s, internal, external: total - internal, total, grade, points: GP[grade] };
  });
  const sgpa = sgpaOf(subjects);
  const hist = history || [1, 2, 3].map(() => clamp(round2(sgpa + (rnd() - 0.5) * 1.4 - 0.2), 5, 10));
  const all = [...hist, sgpa];
  return {
    hallTicket, name, branch, subjects, sgpa, history: all,
    cgpa: round2(all.reduce((a, b) => a + b, 0) / all.length),
    creditsEarned: subjects.filter(s => s.grade !== "F").reduce((a, s) => a + s.credits, 0),
  };
}

const students = [];
for (const [code, [full, count]] of Object.entries(BRANCHES)) {
  for (let i = 0; i < count; i++) {
    const ability = (rnd() + rnd() + rnd() - 1.5) * 22;
    const totals = SUBJECTS.map(s => clamp(Math.round(s.mean + ability + (rnd() - 0.5) * 24), 15, 100));
    students.push(build(`22${code}${101 + i}`, `${pick(FIRST)} ${pick(LAST)}`, full, totals, null));
  }
}
// Demo student: SGPA works out to exactly 8.85
students[students.findIndex(s => s.hallTicket === "22CSE104")] =
  build("22CSE104", "Ananya Reddy", "Computer Science", [85, 86, 74, 82, 92, 75], [8.2, 8.5, 8.7]);

/* ========== STEP C: Tabs ========== */
const $ = id => document.getElementById(id);
let analyticsReady = false;
function showView(v) {
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.view === v));
  document.querySelectorAll(".view").forEach(s => s.classList.toggle("active", s.id === v));
  if (v === "analytics" && !analyticsReady) { initAnalytics(); analyticsReady = true; }
}
document.querySelectorAll(".tab").forEach(t => t.addEventListener("click", () => showView(t.dataset.view)));

/* ========== STEP D: Hall ticket lookup + marksheet ========== */
let trendChart;
function lookup(value) {
  const key = value.trim().toUpperCase();
  const st = students.find(s => s.hallTicket === key);
  if (!st) {
    $("msg").textContent = `No result found for "${key}". Check the hall ticket number (example: 22CSE104).`;
    $("marksheet").hidden = true;
    return;
  }
  $("msg").textContent = "";
  renderMarksheet(st);
}
$("searchForm").addEventListener("submit", e => { e.preventDefault(); lookup($("ht").value); });

function renderMarksheet(st) {
  const rows = st.subjects.map(s => `
    <tr class="${s.grade === "F" ? "fail" : ""}">
      <td>${s.code}</td><td>${s.name}</td><td>${s.credits}</td>
      <td>${s.internal}</td><td>${s.external}</td><td>${s.total}</td>
      <td>${s.grade}</td><td>${s.points}</td><td>${s.grade === "F" ? "Fail" : "Pass"}</td>
    </tr>`).join("");
  const sheet = $("marksheet");
  sheet.hidden = false;
  sheet.innerHTML = `
    <div class="ms-head"><h2>University Examination Board</h2><p>Semester 4 Grade Sheet · B.Tech</p></div>
    <div class="info">
      <div><span>Name:</span> ${st.name}</div><div><span>Hall ticket:</span> ${st.hallTicket}</div>
      <div><span>Branch:</span> ${st.branch}</div><div><span>Credits earned:</span> ${st.creditsEarned}</div>
    </div>
    <div class="tablewrap"><table>
      <thead><tr><th>Code</th><th>Subject</th><th>Credits</th><th>Internal /40</th><th>External /60</th><th>Total</th><th>Grade</th><th>Points</th><th>Status</th></tr></thead>
      <tbody>${rows}</tbody>
    </table></div>
    <div class="result">
      <div class="sgpa"><b>${st.sgpa.toFixed(2)}</b><small>SGPA</small></div>
      <dl><dt>CGPA (4 semesters)</dt><dd>${st.cgpa.toFixed(2)}</dd><dt>Result</dt><dd>${classOf(st)}</dd></dl>
    </div>
    <div class="trend"><canvas id="trendChart"></canvas></div>
    <button class="printbtn" onclick="window.print()">Print / save as PDF</button>`;

  if (trendChart) trendChart.destroy();
  trendChart = new Chart($("trendChart"), {
    type: "line",
    data: { labels: st.history.map((_, i) => `Sem ${i + 1}`),
      datasets: [{ label: "SGPA", data: st.history, borderColor: "#C8372D", backgroundColor: "#C8372D", tension: .25 }] },
    options: { maintainAspectRatio: false, scales: { y: { min: 4, max: 10 } }, plugins: { title: { display: true, text: "SGPA trend" } } },
  });
}

/* ========== STEP E: Batch analytics (computed once) ========== */
function initAnalytics() {
  Chart.defaults.font.family = "IBM Plex Sans, system-ui, sans-serif";
  const INK = "#1B2A49", PEN = "#C8372D";

  // Subject pass rates
  const rates = SUBJECTS.map(s => ({
    name: s.name,
    rate: round1(students.filter(st => st.subjects.find(x => x.code === s.code).grade !== "F").length / students.length * 100),
  }));
  const lowest = rates.reduce((a, b) => (b.rate < a.rate ? b : a));
  new Chart($("passChart"), {
    type: "bar",
    data: { labels: rates.map(r => r.name),
      datasets: [{ label: "Pass %", data: rates.map(r => r.rate), backgroundColor: rates.map(r => r === lowest ? PEN : INK) }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { min: 0, max: 100 } } },
  });

  // Grade distribution (all subjects)
  const grades = Object.keys(GP);
  const gradeCounts = grades.map(g => students.reduce((a, st) => a + st.subjects.filter(s => s.grade === g).length, 0));
  new Chart($("gradeChart"), {
    type: "doughnut",
    data: { labels: grades, datasets: [{ data: gradeCounts,
      backgroundColor: ["#1B2A49","#2E4A7D","#4A6FA5","#7E9CC9","#B5C6E0","#E3C9A8","#D98C6A","#C8372D"] }] },
    options: { maintainAspectRatio: false, plugins: { legend: { position: "right" } } },
  });

  // CGPA histogram
  const BINS = [["Below 6", 0, 6], ["6–7", 6, 7], ["7–8", 7, 8], ["8–9", 8, 9], ["9–10", 9, 10.01]];
  new Chart($("cgpaChart"), {
    type: "bar",
    data: { labels: BINS.map(b => b[0]),
      datasets: [{ label: "Students", data: BINS.map(([, lo, hi]) => students.filter(s => s.cgpa >= lo && s.cgpa < hi).length),
        backgroundColor: INK, categoryPercentage: 1, barPercentage: .95 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
  });

  // Summary strip
  const passedAll = students.filter(st => st.subjects.every(s => s.grade !== "F")).length;
  $("summary").innerHTML = [
    [students.length, "students evaluated"],
    [round1(passedAll / students.length * 100) + "%", "cleared every subject"],
    [`${lowest.name} (${lowest.rate}%)`, "lowest pass rate"],
    [round2(students.reduce((a, s) => a + s.cgpa, 0) / students.length).toFixed(2), "average CGPA"],
  ].map(([v, l]) => `<div class="stat"><b>${v}</b><span>${l}</span></div>`).join("");

  // Leaderboard
  const sel = $("branchSel");
  sel.innerHTML = `<option value="ALL">All branches</option>` +
    Object.values(BRANCHES).map(([full]) => `<option>${full}</option>`).join("");
  sel.addEventListener("change", renderBoard);
  renderBoard();
}

function renderBoard() {
  const b = $("branchSel").value;
  const top = students.filter(s => b === "ALL" || s.branch === b)
    .sort((x, y) => y.sgpa - x.sgpa || y.creditsEarned - x.creditsEarned || x.hallTicket.localeCompare(y.hallTicket))
    .slice(0, 10);
  $("board").innerHTML = top.map((s, i) => `
    <li data-ht="${s.hallTicket}" title="Open marksheet">
      <span class="badge ${i < 3 ? "r" + (i + 1) : ""}">${i + 1}</span>
      <div>${s.name}<small>${s.hallTicket} · ${s.creditsEarned} credits</small></div>
      <span class="score">${s.sgpa.toFixed(2)}</span>
    </li>`).join("");
  $("board").querySelectorAll("li").forEach(li => li.addEventListener("click", () => {
    $("ht").value = li.dataset.ht; showView("lookup"); lookup(li.dataset.ht);
  }));
}