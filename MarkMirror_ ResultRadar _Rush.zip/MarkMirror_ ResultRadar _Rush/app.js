"use strict";

/* ---------- 1. Grading scale & subjects ---------- */
const GRADE_POINTS = { O: 10, "A+": 9, A: 8, "B+": 7, B: 6, C: 5, P: 4, F: 0 };
const SUBJECTS = [
  { code: "MA501", name: "Mathematics", credits: 4, bias: 0 },
  { code: "CS502", name: "DBMS", credits: 4, bias: 0 },
  { code: "CS503", name: "Operating Systems", credits: 4, bias: -9 },
  { code: "CS504", name: "Computer Networks", credits: 3, bias: -2 },
  { code: "CS505", name: "Software Engineering", credits: 3, bias: 3 },
  { code: "CS506", name: "AI Lab", credits: 2, bias: 6 },
];
const SEM_CREDITS = SUBJECTS.reduce((s, x) => s + x.credits, 0);

/* ---------- 2. Grade + GPA utilities ---------- */
function letterGrade(total, external) {
  if (external < 24 || total < 40) return "F"; // must clear external (40%) and total
  if (total >= 90) return "O";
  if (total >= 80) return "A+";
  if (total >= 70) return "A";
  if (total >= 60) return "B+";
  if (total >= 55) return "B";
  if (total >= 50) return "C";
  return "P";
}

// GPA = sum(credits * gradePoints) / sum(credits)
function calcGPA(subjects) {
  const totalCredits = subjects.reduce((s, x) => s + x.credits, 0);
  const weighted = subjects.reduce((s, x) => s + x.credits * GRADE_POINTS[x.grade], 0);
  return weighted / totalCredits;
}

/* ---------- 3. Seeded dataset (100 students) ---------- */
function rng(seed) { // mulberry32 – same data every load
  return function () {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = rng(2022);
const FIRST = ["Aarav","Vivaan","Ananya","Diya","Rohan","Sneha","Karthik","Priya","Arjun","Meera","Ravi","Kavya","Sai","Nikhil","Pooja","Harsha","Isha","Manoj","Lakshmi","Varun"];
const LAST = ["Reddy","Sharma","Rao","Kumar","Patel","Naidu","Singh","Verma","Gupta","Chary"];
const BRANCHES = [["CSE", 40], ["IT", 30], ["ECE", 30]];

function buildStudents() {
  const list = [];
  let n = 0;
  for (const [branch, count] of BRANCHES) {
    for (let i = 0; i < count; i++, n++) {
      const ability = 52 + rand() * 40 + (rand() - 0.5) * 10; // student strength
      const subs = SUBJECTS.map((s) => {
        const target = ability + s.bias + (rand() - 0.5) * 24;
        const total = Math.max(15, Math.min(100, Math.round(target)));
        const internal = Math.min(40, Math.round(total * 0.4 + (rand() - 0.5) * 4));
        const external = Math.max(0, Math.min(60, total - internal));
        const t = internal + external;
        const grade = letterGrade(t, external);
        return { code: s.code, name: s.name, credits: s.credits, internal, external, total: t, grade, points: GRADE_POINTS[grade], pass: grade !== "F" };
      });
      const sgpa = calcGPA(subs);
      const prev = [0, 1].map(() => Math.max(4, Math.min(10, sgpa + (rand() - 0.5) * 1.6)));
      const cgpa = (prev[0] * 20 + prev[1] * 20 + sgpa * SEM_CREDITS) / (40 + SEM_CREDITS);
      list.push({
        hallTicket: `22${branch}${101 + i}`,
        name: `${FIRST[(n * 7) % FIRST.length]} ${LAST[(n * 3) % LAST.length]}`,
        branch, subs, sgpa, cgpa,
      });
    }
  }
  return list;
}
const STUDENTS = buildStudents();

/* ---------- 4. Tabs ---------- */
document.querySelectorAll(".tab").forEach((btn) =>
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).classList.add("active");
    if (btn.dataset.tab === "analytics") renderAnalytics();
  })
);

/* ---------- 5. Result lookup ---------- */
const $ = (id) => document.getElementById(id);

$("searchForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const ht = $("hallTicket").value.trim().toUpperCase();
  const s = STUDENTS.find((x) => x.hallTicket === ht);
  if (!s) {
    $("marksheet").hidden = true;
    $("msg").textContent = `No result found for "${ht}". Try 22CSE104.`;
    return;
  }
  $("msg").textContent = "";
  showMarksheet(s);
});

function showMarksheet(s) {
  $("mName").textContent = s.name;
  $("mHT").textContent = s.hallTicket;
  $("mBranch").textContent = s.branch;
  $("mRows").innerHTML = s.subs.map((x) => `
    <tr>
      <td>${x.code}</td><td>${x.name}</td><td>${x.credits}</td>
      <td>${x.internal}</td><td>${x.external}</td><td>${x.total}</td>
      <td class="${x.pass ? "" : "fail"}">${x.grade}</td><td>${x.points}</td>
    </tr>`).join("");
  const failed = s.subs.some((x) => !x.pass);
  $("mSgpa").textContent = s.sgpa.toFixed(2);
  $("mCgpa").textContent = s.cgpa.toFixed(2);
  $("mCredits").textContent = SEM_CREDITS;
  $("mResult").textContent = failed ? "BACKLOG" : s.sgpa >= 8.5 ? "DISTINCTION" : "PASS";
  $("mResult").className = failed ? "fail" : "";
  $("marksheet").hidden = false;
}
$("printBtn").addEventListener("click", () => window.print());

/* ---------- 6. Batch analytics (pre-computed once) ---------- */
function computeStats() {
  const subjectStats = SUBJECTS.map((sub, i) => {
    const passed = STUDENTS.filter((s) => s.subs[i].pass).length;
    return { name: sub.name, rate: +((passed / STUDENTS.length) * 100).toFixed(1) };
  });
  const gradeCount = Object.fromEntries(Object.keys(GRADE_POINTS).map((g) => [g, 0]));
  STUDENTS.forEach((s) => s.subs.forEach((x) => gradeCount[x.grade]++));

  const bins = [0, 0, 0, 0, 0, 0]; // <5, 5-6, 6-7, 7-8, 8-9, 9-10
  STUDENTS.forEach((s) => bins[Math.max(0, Math.min(5, Math.floor(s.cgpa) - 4))]++);

  const totalPass = STUDENTS.reduce((a, s) => a + s.subs.filter((x) => x.pass).length, 0);
  return {
    subjectStats, gradeCount, bins,
    overallPass: (totalPass / (STUDENTS.length * SUBJECTS.length)) * 100,
    avgCgpa: STUDENTS.reduce((a, s) => a + s.cgpa, 0) / STUDENTS.length,
  };
}
const STATS = computeStats();
let charts = [];

function renderAnalytics() {
  const hardest = STATS.subjectStats.reduce((a, b) => (b.rate < a.rate ? b : a));
  $("kStudents").textContent = STUDENTS.length;
  $("kPass").textContent = STATS.overallPass.toFixed(1) + "%";
  $("kHard").textContent = `${hardest.name} (${hardest.rate}%)`;
  $("kAvg").textContent = STATS.avgCgpa.toFixed(2);

  charts.forEach((c) => c.destroy());
  charts = [
    new Chart($("passChart"), {
      type: "bar",
      data: {
        labels: STATS.subjectStats.map((s) => s.name),
        datasets: [{ label: "Pass %", data: STATS.subjectStats.map((s) => s.rate), backgroundColor: "#4f46e5" }],
      },
      options: { scales: { y: { beginAtZero: true, max: 100 } }, plugins: { legend: { display: false } } },
    }),
    new Chart($("gradeChart"), {
      type: "doughnut",
      data: {
        labels: Object.keys(STATS.gradeCount),
        datasets: [{ data: Object.values(STATS.gradeCount),
          backgroundColor: ["#16a34a","#22c55e","#84cc16","#eab308","#f97316","#f43f5e","#a855f7","#dc2626"] }],
      },
    }),
    new Chart($("cgpaChart"), {
      type: "bar",
      data: {
        labels: ["< 5", "5-6", "6-7", "7-8", "8-9", "9-10"],
        datasets: [{ label: "Students", data: STATS.bins, backgroundColor: "#0ea5e9", barPercentage: 1, categoryPercentage: 1 }],
      },
      options: { scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } },
    }),
  ];
  renderBoard();
}

function renderBoard() {
  const b = $("branchSel").value;
  const medals = ["🥇", "🥈", "🥉"];
  const top = STUDENTS.filter((s) => b === "All" || s.branch === b)
    .sort((x, y) => y.sgpa - x.sgpa || y.cgpa - x.cgpa)
    .slice(0, 10);
  $("board").innerHTML = top.map((s, i) => `
    <li>
      <span class="rank">${medals[i] || i + 1}</span>
      <span class="nm">${s.name}<small>${s.hallTicket} · ${s.branch}</small></span>
      <span>SGPA <b>${s.sgpa.toFixed(2)}</b></span>
    </li>`).join("");
}
$("branchSel").addEventListener("change", renderBoard);